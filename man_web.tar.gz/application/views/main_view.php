<center>
        <h2>Главная</h2>
</center>
        <?=$result['news']; ?>

