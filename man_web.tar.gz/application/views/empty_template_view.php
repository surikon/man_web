<html>
    <head>
        <meta charset = "utf-8">
        <title>Surnachev_Nikita</title>
    </head>
    <body>
        <?php include 'application/views/'.$content_view; ?>
    </body>
</html>