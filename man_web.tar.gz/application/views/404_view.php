<center>
    <img src="/images/error_404.png" width = "40%" height="10%">
<h3>Извините, такой страницы не существует. <a href = "http://localhost">Главная.</a></h3>
</center>