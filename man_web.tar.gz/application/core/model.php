<?php
    class Model
    {
        private $data;
        public function get_data()
        {
        }
    }
