<?php
    class Model_Journal extends Model
    {

    }
?>