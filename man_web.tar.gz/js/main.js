function goOut(h) {
    location.href = h;
}